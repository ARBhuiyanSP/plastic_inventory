<!-- Modal -->
<div class="modal fade" id="sub_item_edit_form" role="dialog">
    <form id="sub_item_update_form_value">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header modal_header_custom_background">
                    <h4 class="modal-title">Sub category updated</h4>
                </div>
                <div class="modal-body modal_body_custom_background">
                    <div class="modal_body_centerize">
                        <div id="sub_material_edit_data_section"></div>
                    </div>
                </div>
                <div class="modal-footer modal_footer_custom_background">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-default" onclick="processSubItems('sub_item_update_form_value')">Update</button>
                </div>
            </div>
        </div>
    </form>
</div>